from django.apps import AppConfig


class TicketbookingConfig(AppConfig):
    name = 'ticketbooking'
